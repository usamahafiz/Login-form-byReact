import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import './App.css';
import Login from './auth/Login';
import Register from './auth/Register';
import Forget from './auth/Forget';


function App() {
  return (
     <>
        
    

  
    <Router>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/Register" element={<Register />} />
          <Route path="/Forget" element={<Forget />} />
        </Routes>
      
    </Router>

    </>
  );
}

export default App;
